(function(){
  'use strict';
  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];

  // Mobile navigation
  const navToggle=$('.nav-toggle'), mainNav=$('.main-nav');
  if(navToggle&&mainNav){
    navToggle.addEventListener('click',()=>{const open=mainNav.classList.toggle('open');navToggle.setAttribute('aria-expanded',String(open));});
    $$('.main-nav a').forEach(a=>a.addEventListener('click',()=>{mainNav.classList.remove('open');navToggle.setAttribute('aria-expanded','false');}));
  }

  function toast(message){
    let el=$('.site-toast');
    if(!el){el=document.createElement('div');el.className='site-toast';document.body.appendChild(el);}
    el.textContent=message; el.classList.add('show'); clearTimeout(window.__siteToastTimer);
    window.__siteToastTimer=setTimeout(()=>el.classList.remove('show'),2800);
  }

  function modal(title,body,actions='Close'){
    let m=$('.site-modal');
    if(!m){
      m=document.createElement('div');m.className='site-modal';m.innerHTML='<div class="site-modal-backdrop"></div><section class="site-modal-panel" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><button class="site-modal-close" aria-label="Close">×</button><div class="eyebrow">PATRIOT FEDERAL BANK</div><h2 id="modalTitle"></h2><div class="site-modal-body"></div><div class="site-modal-actions"></div></section>';document.body.appendChild(m);
      $('.site-modal-backdrop',m).onclick=()=>m.classList.remove('open'); $('.site-modal-close',m).onclick=()=>m.classList.remove('open');
    }
    $('#modalTitle',m).textContent=title; $('.site-modal-body',m).innerHTML=body;
    const acts=$('.site-modal-actions',m); acts.innerHTML='';
    const b=document.createElement('button');b.className='btn btn-primary';b.textContent=actions;b.onclick=()=>m.classList.remove('open');acts.appendChild(b);
    m.classList.add('open'); setTimeout(()=>$('.site-modal-close',m).focus(),30);
  }

  // Safe interactive placeholder actions: no credentials, money or personal data are transmitted.
  $$('[data-action]').forEach(el=>el.addEventListener('click',e=>{
    e.preventDefault();
    const a=el.dataset.action;
    const map={
      transfer:['Transfer Money','Choose an eligible account, enter a transfer amount and review the details before submitting. This interface is a local presentation flow; no funds are moved.'],
      billpay:['Pay a Bill','Select a payee, choose a payment date and review the amount. This presentation flow does not send a payment.'],
      cards:['Card Controls','View card status, lock/unlock controls, spending limits and recent card activity in this banking interface.'],
      statements:['Statements','Choose a statement period to preview account documents. Downloads are presentation-only.'],
      alerts:['Alerts','Review sign-in, account and payment notifications from one place.'],
      security:['Security Center','Review authentication settings, login activity and account-security guidance.'],
      account:['Account Details','Review account type, available balance, recent activity and account details.'],
      support:['Support Center','Find help articles, contact options, security guidance and location information.']
    };
    if(a==='transfer') return openTransfer();
    if(map[a]) modal(map[a][0],'<p>'+map[a][1]+'</p>'); else toast('This section is ready for the next product build.');
  }));


  function openTransfer(){
    let m=$('.site-modal');
    if(!m){
      m=document.createElement('div');m.className='site-modal';m.innerHTML='<div class="site-modal-backdrop"></div><section class="site-modal-panel" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><button class="site-modal-close" aria-label="Close">×</button><div class="eyebrow">PATRIOT FEDERAL BANK</div><h2 id="modalTitle"></h2><div class="site-modal-body"></div><div class="site-modal-actions"></div></section></div>';document.body.appendChild(m);
      $('.site-modal-backdrop',m).onclick=()=>m.classList.remove('open'); $('.site-modal-close',m).onclick=()=>m.classList.remove('open');
    }
    $('#modalTitle',m).textContent='Transfer Money';
    $('.site-modal-body',m).innerHTML=`
      <form class="transfer-form" id="transferForm">
        <div class="transfer-step"><span>1</span><div><strong>Recipient details</strong><small>Send to another U.S. bank account</small></div></div>
        <label>From account
          <select id="transferFrom" required>
            <option value="checking">Checking — $204,865.00</option>
            <option value="savings">Savings — $423,309.00</option>
          </select>
        </label>
        <label>Recipient type
          <select id="recipientType" required>
            <option value="">Recipient type</option>
            <option>Individual</option>
            <option>Business</option>
          </select>
        </label>
        <label>Recipient name
          <input id="recipientName" type="text" autocomplete="off" placeholder="Full recipient name" required>
        </label>
        <label>Recipient country
          <input value="United States" readonly aria-readonly="true">
        </label>
        <label>Scheme
          <select id="transferScheme" required>
            <option value="">Scheme</option>
            <option value="ach">ACH</option>
            <option value="wire">Wire transfer</option>
          </select>
        </label>
        <label>Bank name
          <input id="bankName" type="text" autocomplete="off" placeholder="Bank name" required>
        </label>
        <label>Routing number
          <input id="routingNumber" type="text" inputmode="numeric" maxlength="9" autocomplete="off" placeholder="9-digit routing number" required>
        </label>
        <label>Account number
          <input id="recipientAccount" type="text" inputmode="numeric" maxlength="17" autocomplete="off" placeholder="Enter account number" required>
        </label>
        <label>Account type
          <select id="recipientAccountType" required>
            <option value="">Account type</option>
            <option>Checking</option>
            <option>Savings</option>
          </select>
        </label>
        <label>Recipient street address
          <input id="recipientStreet" type="text" autocomplete="off" placeholder="Street address starting with the house number" required>
        </label>
        <label>Recipient city
          <input id="recipientCity" type="text" autocomplete="off" placeholder="Enter recipient city" required>
        </label>
        <label>Recipient state
          <select id="recipientState" required>
            <option value="">Recipient state</option>
            <option>Alabama</option><option>Alaska</option><option>Arizona</option><option>Arkansas</option><option>California</option><option>Colorado</option><option>Connecticut</option><option>Delaware</option><option>Florida</option><option>Georgia</option><option>Hawaii</option><option>Idaho</option><option>Illinois</option><option>Indiana</option><option>Iowa</option><option>Kansas</option><option>Kentucky</option><option>Louisiana</option><option>Maine</option><option>Maryland</option><option>Massachusetts</option><option>Michigan</option><option>Minnesota</option><option>Mississippi</option><option>Missouri</option><option>Montana</option><option>Nebraska</option><option>Nevada</option><option>New Hampshire</option><option>New Jersey</option><option>New Mexico</option><option>New York</option><option>North Carolina</option><option>North Dakota</option><option>Ohio</option><option>Oklahoma</option><option>Oregon</option><option>Pennsylvania</option><option>Rhode Island</option><option>South Carolina</option><option>South Dakota</option><option>Tennessee</option><option>Texas</option><option>Utah</option><option>Vermont</option><option>Virginia</option><option>Washington</option><option>West Virginia</option><option>Wisconsin</option><option>Wyoming</option>
          </select>
        </label>
        <label>Recipient ZIP code
          <input id="recipientZip" type="text" inputmode="numeric" maxlength="10" autocomplete="off" placeholder="Enter recipient ZIP code" required>
        </label>
        <label class="toggle-row"><span>Save as beneficiary</span><input id="saveBeneficiary" type="checkbox"><span class="fake-toggle" aria-hidden="true"></span></label>
        <div class="transfer-divider"></div>
        <div class="transfer-step"><span>2</span><div><strong>Transfer amount</strong><small>Choose how much to send</small></div></div>
        <label>Amount
          <div class="amount-field"><span>$</span><input id="transferAmount" type="number" min="0.01" step="0.01" placeholder="0.00" required></div>
        </label>
        <label>Memo <span class="optional">Optional</span>
          <input id="transferMemo" type="text" maxlength="80" autocomplete="off" placeholder="Add a note">
        </label>
        <div class="transfer-review-card" id="transferReviewCard">
          <strong>Review before submitting</strong>
          <p id="transferReviewText">Your transfer details will appear here.</p>
        </div>
        <div class="transfer-step"><span>3</span><div><strong>Authorize transfer</strong><small>Enter your transfer PIN to submit</small></div></div>
        <label>Transfer PIN
          <input id="transferPin" type="password" inputmode="numeric" maxlength="4" placeholder="••••" required>
        </label>
        <p class="form-note">This presentation flow does not move money or connect to an external bank.</p>
        <button class="btn btn-primary full-width" type="submit">Submit Transfer</button>
      </form>`;
    $('.site-modal-actions',m).innerHTML='';
    m.classList.add('open');

    const form=$('#transferForm',m);
    const review=()=>{
      const name=$('#recipientName',m).value.trim()||'Recipient';
      const bank=$('#bankName',m).value.trim()||'External bank';
      const amount=Number($('#transferAmount',m).value);
      const scheme=$('#transferScheme',m).value;
      $('#transferReviewText',m).textContent = (Number.isFinite(amount)&&amount>0)
        ? `$${amount.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})} from ${$('#transferFrom',m).selectedOptions[0].textContent.split('—')[0].trim()} to ${name} at ${bank}${scheme?' via '+scheme.toUpperCase():''}.`
        : `From ${$('#transferFrom',m).selectedOptions[0].textContent.split('—')[0].trim()} to ${name} at ${bank}.`;
    };
    ['recipientName','bankName','transferAmount','transferScheme','transferFrom'].forEach(id=>$('#'+id,m)?.addEventListener('input',review));
    review();

    form.addEventListener('submit',e=>{
      e.preventDefault();
      const amount=Number($('#transferAmount',m).value), pin=$('#transferPin',m).value.trim(), routing=$('#routingNumber',m).value.trim(), account=$('#recipientAccount',m).value.trim();
      if(!Number.isFinite(amount)||amount<=0){toast('Enter a valid transfer amount.');return;}
      if(!/^\d{9}$/.test(routing)){toast('Enter a valid 9-digit routing number.');return;}
      if(!/^\d{4,17}$/.test(account)){toast('Enter a valid account number.');return;}
      if(pin!=='9382'){toast('The transfer PIN is incorrect.');return;}
      m.classList.remove('open');
      setTimeout(()=>modal('Transaction Failed','<p>We were unable to complete this transfer to the external U.S. bank account.</p><p>No funds were moved and your checking or savings balance was not changed.</p><p class="form-note">Please try again later or contact support if you need assistance.</p>'),120);
    });
    setTimeout(()=>$('#transferFrom',m).focus(),30);
  }

  // Action buttons are handled by the data-action listener above.

  // Password visibility only changes the field type; it never transmits the value.
  const pass=$('#password'), toggle=$('.password-toggle');
  if(pass&&toggle) toggle.addEventListener('click',()=>{const show=pass.type==='password';pass.type=show?'text':'password';toggle.textContent=show?'Hide':'Show';toggle.setAttribute('aria-label',show?'Hide password':'Show password');});

  // Local-only portfolio authentication. Nothing is transmitted to a server.
  const form=$('#loginForm'), message=$('#loginMessage');
  if(form){form.addEventListener('submit',e=>{
    e.preventDefault();
    const u=$('#username'), p=$('#password');
    const validUsername='Foreverlove';
    const validPassword='Lemus112@';
    if(!u?.value.trim()||!p?.value){
      if(message){message.textContent='Enter your username and password to continue.';message.style.color='#b34843';}
      return;
    }
    if(u.value.trim()!==validUsername || p.value!==validPassword){
      if(message){message.textContent='The username or password you entered is incorrect.';message.style.color='#b34843';}
      return;
    }
    p.value='';
    sessionStorage.setItem('patriotPreview','1');
    window.location.href='dashboard.html';
  });}

  // Clear session on sign-out.
  $$('a[href="index.html"]').filter(a=>/sign out/i.test(a.textContent)).forEach(a=>a.addEventListener('click',()=>sessionStorage.removeItem('patriotPreview')));

  // Smooth same-page navigation.
  $$('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const id=a.getAttribute('href');if(id&&id!=='#'&&$(id)){e.preventDefault();$(id).scrollIntoView({behavior:'smooth',block:'start'});history.replaceState(null,'',id);}}));
})();
