PATRIOT FEDERAL BANK — FRONTEND DEMO

This is a fictional portfolio/school/startup presentation website.
Patriot Federal Bank is not a real financial institution.
All balances, accounts, transactions, cards and workflows are simulated.

FILES
- index.html      Public marketing homepage
- login.html      Fictional online banking login
- dashboard.html  Fictional customer dashboard
- css/style.css   Global responsive design system
- js/main.js      Navigation, demo login and UI interactions
- assets/         Placeholder folders for future images/icons

OPEN LOCALLY
1. Extract the project folder.
2. Double-click index.html, or right-click it and open it in a browser.
3. Click "Demo Online Banking".
4. Use:
   Username: Elaine Kimberly
   Password: gyuhojhedfeg

The login is local-only and does not send credentials to a server.
No backend or real financial processing is included.
